# Malevich XL / 7×TMC2209 — release candidate 3

RC3 makes the known Designer XL PB1 Z setup part of the selectable XL installer profile. It installs the Z host module and `xl_z_probe.cfg` together with the XL `G28` macros and bed-mesh config. The installer leaves the active config unchanged with `--keep-config`.

## Requirements and pin config

The Klipper host must already contain `klippy/extras/trigger_analog.py`; the installer checks this dependency before writing firmware. The module uses the existing Malevich MCU BIN v0.2.0 and its `analog_in_attach_trigger_analog` command. No new MCU binary is built or installed.

Pin assignments are visible in the profile files, never hidden in the Python guard: `board_pins.cfg` maps `TMC_UART=PB10`, `TMC_DIAG1=PE15`, `TMC_BANK=PC3`; `printer.cfg` uses the aliases for UART, X/Y/E `diag_pin`, and bank selection; `xl_z_probe.cfg` sets the load cell to PB1 and supply to PA0. The DIAG Guard reads the active Klipper config.

The Z threshold (1493 mV), park coordinates, mesh area, and 618 mm Z search ceiling are calibrated for the tested XL. Verify them for another printer before motion. The profile remains a release candidate; this update wires the existing tested sequence into installation, with no additional hardware retest. Heater control starts with watermark settings and requires PID calibration before printing.

## Files

- `malevich_diag_guard_v0.2.0-rc1.zip` — shared X/Y sensorless guard for compatible TMC2209 pin topology; supports matching printers with their own configured `diag_pin`.
- `malevich_xl_klipper_v0.5.0-rc1.zip` — PB1 host module and standalone examples.
- `designer_xl_profile_v0.3.6-rc1.zip` — ready XL profile files, including the active Z config and G28 macros.
- `SHA256SUMS.json` — hashes of the component archives.

For installations on other compatible printers, DIAG Guard can be applied through the installer when the real printer pin aliases and X/Y virtual endstops are configured. The shared-DIAG/INDEX line is assumed for non-Z drivers; Z remains outside DIAG Guard.

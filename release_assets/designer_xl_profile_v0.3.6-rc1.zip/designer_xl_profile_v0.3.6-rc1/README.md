# Designer XL ready profile (0.3.6-rc1)

This profile enables the PB1 Z probe, the two-stage XL `G28`, and a 3x3 bed mesh when installed through the Malevich installer. It targets the tested Designer XL with seven TMC2209 drivers. The load-cell threshold (1493 mV), park point, mesh area, and 618 mm search ceiling are machine-calibrated values; verify them for a different physical printer before motion.

The profile requires `klippy/extras/trigger_analog.py`, which must already be present on the Klipper host. The installer checks for it before flashing and installs the matching `malevich_xl_z_probe.py` host module. `--keep-config` leaves the current printer config and macros unchanged.

Pin mapping is kept in Klipper config: `board_pins.cfg` maps `TMC_UART=PB10`, `TMC_DIAG1=PE15`, and `TMC_BANK=PC3`; `printer.cfg` refers to the aliases for UART, DIAG, and bank selection; `xl_z_probe.cfg` sets the load cell to PB1 and supply to PA0. DIAG Guard contains no board GPIO assignments.

The profile uses the existing Malevich MCU Klipper BIN v0.2.0. This package does not replace the binary or add MCU commands. PID tuning remains printer-specific; the profile uses conservative watermark control until calibration.
